<template>
#[[$END$]]#
</template>

<script>
export default {
name: "${COMPONENT_NAME}",
data() {

},
created() {

},
methods() {

},
</script>

<style lang=’scss‘ scoped>

</style>